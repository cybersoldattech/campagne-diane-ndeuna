<?php
header("Location: ./src/pages/index.php");
