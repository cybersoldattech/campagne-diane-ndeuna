function openModal() {
    document.getElementById('large-modal').classList.toggle('hidden');
}